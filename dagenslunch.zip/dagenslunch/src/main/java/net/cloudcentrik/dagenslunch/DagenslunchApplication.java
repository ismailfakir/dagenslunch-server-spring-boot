package net.cloudcentrik.dagenslunch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DagenslunchApplication {

	public static void main(String[] args) {
		SpringApplication.run(DagenslunchApplication.class, args);
	}
}
